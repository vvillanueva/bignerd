//
//  NSString+VowelCounter.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NSString+VowelCounter.h"

@implementation NSString (VowelCounter)

- (int) vowelCount{
    NSCharacterSet *charSet = [NSCharacterSet characterSetWithCharactersInString:@"aeiouyAEIOUY"];
    NSUInteger count = [self length];
    int sum = 0;
    for (int i = 0; i < count; i++){
        unichar c = [self characterAtIndex:i];
        if ([charSet characterIsMember:c])
            sum++;
    }
    return sum;
}

@end
