//
//  Logger.h
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Logger : NSObject{
    NSMutableData *incomingData;
}
- (void) sayOuch:(NSTimer *)t;

@end
