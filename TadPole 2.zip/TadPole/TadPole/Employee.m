//
//  Employee.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Employee.h"
#import "Device.h"

@implementation Employee : Person
@synthesize employeeID;
@synthesize userID;
- (id)init {
    self = [super init];
    if (self) {
        devices = [NSMutableArray array];
        Device *d = [[Device alloc] init];
        [d setDescriptiveName:@"Windows 8"];
        [d setDeviceID:@"9"];
        [devices addObject: d];
    }
    return self;
}

- (void)addDevice:(id) deviceID{
    
    [devices addObject:deviceID];
}

- (NSMutableArray*)getDevices{
    return devices;
}

- (void)dealloc{
    NSLog(@"deallocating: %@", self);
}

- (NSString *)description{
    return [NSString stringWithFormat:@"Employee %@: %@", [self userID], [devices count]];
}


@end
