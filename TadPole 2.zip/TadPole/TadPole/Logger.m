//
//  Logger.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Logger.h"

@implementation Logger

- (void) sayOuch:(NSTimer *)t{
    NSLog(@"Ouch!");
}

- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    NSLog(@"receiving %lu bytes...", [data length]);
    
    if (!incomingData){
        incomingData = [[NSMutableData alloc] init];
        
    }
    [incomingData appendData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection{
    NSLog(@"Got it all");
    
    NSString *allData = [[NSString alloc] initWithData:incomingData encoding:NSUTF8StringEncoding];
    NSLog(@"All data ... %@", allData);
    
    incomingData = nil;
    
    
}

- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"Connection failed...%@", [error localizedDescription]);
    incomingData = nil;
}

@end
