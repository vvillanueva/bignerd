//
//  main.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Device.h"
#import "Employee.h"
#import "NSString+VowelCounter.h"

@class Logger;

int main (int argc, const char * argv[])
{

    @autoreleasepool {
        
        Device *d = [[Device alloc ] init ];
        [d setDescriptiveName:@"Samsumg Galaxy"];
        [d setDeviceID:@"14"];
        
        
     /*   Employee *p = [[Employee alloc] init];
        [p setUserID:@"vvillanueva"];
        [p setEmployeeID:1177];
        [p setFname:@"vince"];
        [p setLname:@"villanueva"];
        [p setPhone_number:@"408-823-9627"];
        [p addDevice:d];*/
        
        Employee *p = [[Employee alloc] init:@"vince"
                                       lname:@"villanueva"
                                       phone:@"408-823-9627"];
        [p setUserID:@"vvillanueva"];

        Device *ddd = [[Device alloc ] init ];
        [ddd setDescriptiveName:@"Apple iPhone 4"];
        [ddd setDeviceID:@"13"];
        [p addDevice:ddd];
        
        Device *dd = [[Device alloc ] init ];
        [dd setDescriptiveName:@"Apple iPhone 4s"];
        [dd setDeviceID:@"12"];
        [p addDevice:dd];


        Employee *pp = [[Employee alloc] init];
//        [pp setUserID:@"capham"];
        [pp setValue:@"capham" forKey:@"userID"];
        [pp setEmployeeID:2222];
        [pp setFname:@"cat"];
        [pp setLname:@"pham"];
        [pp setPhone_number:@"408-376-9627"];
        [pp addDevice:d];
        [pp addDevice:dd];

        
        
        NSLog(@"Devices for %@ %@ at %@ with userID: %@", [p fname], [p lname], [p phone_number], [p userID]);
        
        for (Device *d in [p getDevices]) {
            NSLog(@"Device %@", [d descriptiveName]);
        }
        
        
        NSLog(@"Devices for %@ %@ at %@ with userID: %@", [pp fname], [pp lname], [pp phone_number], [pp userID]);
        
        
        
        for (Device *d in [pp getDevices]) {
            NSLog(@"Device %@", [d descriptiveName]);
        }
        
        
        
     //   [[p getDevices] removeObjectAtIndex:0];
        [[pp getDevices] removeObjectAtIndex:0];
        
        
        NSLog(@"DELETE Devices for %@ %@ at %@ with userID: %@", [pp valueForKey:@"fname"], [pp lname], [pp phone_number], [pp userID]);
        
        
        
        for (Device *d in [pp getDevices]) {
            NSLog(@"Device %@", [d descriptiveName]);
        }
        
        
        NSSortDescriptor *devicesSD = [NSSortDescriptor sortDescriptorWithKey:@"deviceID" ascending:YES];
        NSSortDescriptor *descriptiveNameSD = [NSSortDescriptor sortDescriptorWithKey:@"descriptiveName" ascending:YES];
        
        [[p getDevices] sortUsingDescriptors:[NSArray arrayWithObjects:descriptiveNameSD, devicesSD, nil]];
        
        NSLog(@"\nDevices for %@ %@ at %@ with userID: %@", [p fname], [p lname], [p phone_number], [p userID]);
        
        for (Device *d in [p getDevices]) {
            NSLog(@"Sorted Device %@:%@", [d descriptiveName], [d deviceID]);
        }
        
        NSPredicate *deviceByUserPRED = [NSPredicate predicateWithFormat:@"descriptiveName like \"Apple*\""];
        NSArray *devicesByOwner = [[p getDevices] filteredArrayUsingPredicate:deviceByUserPRED];
        
        NSLog(@"\nApple Devices for %@ %@ at %@ with userID: %@", [p fname], [p lname], [p phone_number], [p userID]);
        
        
        for (Device *d in devicesByOwner) {
            NSLog(@"\n\nFiltered Device %@:%@\n\n", [d descriptiveName], [d deviceID]);
        }
        
   /*     Logger *logger = [[Logger alloc] init];
        
   //     __unused NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2.0
   //                                                       target:logger selector:@selector(sayOuch:) userInfo:nil repeats:YES];
        
        
        NSURLConnection *url = [NSURL URLWithString:@"http://www.gutenberg.org/cache/epub/205/pg205.txt"];
        
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        __unused NSURLConnection *fetchConn = [[NSURLConnection alloc] initWithRequest:request delegate:logger startImmediately:YES];
        
        //__unused NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:logger selector:nil userInfo:nil repeats:YES];
    
        [[NSRunLoop currentRunLoop] run];
        
*/
        
        NSMutableArray *users = [[NSMutableArray alloc]init];
        
        
        NSMutableDictionary *userToDevice;

        userToDevice = [NSMutableDictionary dictionary];
        [userToDevice setObject:p forKey:[p userID]];
        [userToDevice setObject:pp forKey:[pp userID]];
        
        [users addObject:userToDevice];
        
        [users writeToFile:@"~/temp/employees.plist" atomically:YES];
        
        NSLog(@"Done writing file"); 
        NSLog(@"Vowels in emp name: %@ is %d",[p fname], [[p fname] vowelCount]);
        
        NSArray *array = [NSArray arrayWithObjects:@"vince", @"cat",nil];
        
        
       void (^cleanName)(id, NSUInteger, BOOL *) = ^(id string, NSUInteger i, BOOL * stop ){
            NSMutableString *newString = [NSMutableString stringWithString:string];
            if ([newString isEqualToString:@"cat"]){
                [userToDevice setObject:pp forKey:newString];
            }
            
        };
        
        [array enumerateObjectsUsingBlock:cleanName];
        
        for (Device *d in userToDevice){
           // NSLog(@"User %@", [d deviceID]);

        }
        
        
    }
    return 0;
}
                    


