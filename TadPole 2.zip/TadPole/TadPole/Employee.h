//
//  Employee.h
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Person.h"

@interface Employee : Person
{
    NSString* userID;
    int employeeID;
    NSMutableArray *devices;

}
@property int employeeID;
@property (retain) NSString* userID;

- (void)addDevice:(Device*)d;
- (NSMutableArray *)getDevices;

@end
