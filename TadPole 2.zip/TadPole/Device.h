//
//  Device.h
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Device : NSObject
{
    //new way is to use property
   // NSString *deviceID;
   // NSString *descriptiveName;
}
@property (retain) NSString *deviceID;
@property(retain)  NSString *descriptiveName;


@end
