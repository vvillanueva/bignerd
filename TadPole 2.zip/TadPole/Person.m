//
//  Person.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Person.h"

@implementation Person
@synthesize fname;
@synthesize lname;
@synthesize phone_number; 

- (id)init:(NSString *)fn lname:(NSString *)ln phone:(NSString *)phone{
    [super init];
    [self setFname:fn];
    [self setLname:ln];
    [self setPhone_number:phone];
    return self;
}


@end
