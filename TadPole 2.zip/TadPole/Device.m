//
//  Device.m
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Device.h"

@implementation Device

@synthesize deviceID;
@synthesize descriptiveName;

- (void) dealloc{
    NSLog(@"deallocating: %@", self);
}

- (NSString *)description{
    return [NSString stringWithFormat:@"<%@: %@>", [self deviceID], [self descriptiveName]];
}

@end
