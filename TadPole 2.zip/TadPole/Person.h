//
//  Person.h
//  TadPole
//
//  Created by Villanueva, Vincent() on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Device;

@interface Person : NSObject
{
    NSString *lname;
    NSString *fname;
    NSString *phone_number;
}
@property (retain) NSString *lname;
@property (retain) NSString *fname;
@property (retain) NSString *phone_number;

- (id)init:(NSString *)fname
            lname:(NSString *)lname
            phone:(NSString *)phone;


@end
